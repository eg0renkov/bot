import json
import os
import uuid
from typing import Dict, Optional
from datetime import datetime

class TempEmailStorage:
    """Временное хранилище писем в процессе редактирования"""
    
    def __init__(self):
        self.storage_dir = "data/temp_emails"
        os.makedirs(self.storage_dir, exist_ok=True)
    
    def create_email(self, user_id: int, to_email: str, subject: str, body: str) -> str:
        """Создать временное письмо и вернуть его ID"""
        email_id = str(uuid.uuid4())[:8]
        
        email_data = {
            "id": email_id,
            "user_id": user_id,
            "to_email": to_email,
            "subject": subject,
            "body": body,
            "created_at": datetime.now().isoformat()
        }
        
        file_path = os.path.join(self.storage_dir, f"{email_id}.json")
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(email_data, f, ensure_ascii=False, indent=2)
        
        return email_id
    
    def get_email(self, email_id: str) -> Optional[Dict]:
        """Получить письмо по ID"""
        file_path = os.path.join(self.storage_dir, f"{email_id}.json")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return None
    
    def update_email(self, email_id: str, **kwargs):
        """Обновить поля письма"""
        email_data = self.get_email(email_id)
        if not email_data:
            return False
        
        email_data.update(kwargs)
        email_data["updated_at"] = datetime.now().isoformat()
        
        file_path = os.path.join(self.storage_dir, f"{email_id}.json")
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(email_data, f, ensure_ascii=False, indent=2)
        
        return True
    
    def get_user_latest_email(self, user_id: int) -> Optional[Dict]:
        """Получить последнее письмо пользователя"""
        user_emails = []
        
        for filename in os.listdir(self.storage_dir):
            if filename.endswith('.json'):
                email_data = self.get_email(filename[:-5])  # убираем .json
                if email_data and email_data.get('user_id') == user_id:
                    user_emails.append(email_data)
        
        if not user_emails:
            return None
        
        # Сортируем по времени создания и возвращаем последнее
        user_emails.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        return user_emails[0]
    
    def delete_email(self, email_id: str):
        """Удалить временное письмо"""
        file_path = os.path.join(self.storage_dir, f"{email_id}.json")
        if os.path.exists(file_path):
            os.remove(file_path)
    
    def format_email_preview(self, email_data: Dict) -> str:
        """Форматировать предварительный просмотр письма"""
        return f"""📧 <b>Предварительный просмотр письма</b>

<b>📮 Кому:</b> {email_data['to_email']}
<b>📝 Тема:</b> {email_data['subject']}

<b>💌 Текст письма:</b>
{email_data['body']}

<i>Проверьте письмо и выберите действие:</i>"""

# Глобальный экземпляр
temp_emails = TempEmailStorage()